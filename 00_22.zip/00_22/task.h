#pragma once
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <math.h>

static const double richardson[] = {
	1.0 / 3.0, 1.0 / 15.0, 1.0 / 63.0, 1.0 / 255.0, 1.0 / 1023.0, 1.0 / 4095.0
};

#define MAX_COLUMNS 1+sizeof(richardson)/sizeof(richardson[0])
#define max(x,y) ( (x) < (y) ? (y) : (x) )
#define min(x,y) ( (x) < (y) ? (x) : (y) )

int odu(double a, double b, double f0, double f1, double e, double *f, double *temp, int n);

