#pragma once
//y'=f(x,y)
double func(double x, double y) {
	return (y*y/(x*x*x*x)+2*x*x);
	//return (-exp(3 * x)*y / (exp(3 * x) + 1) + 2 * exp(2 * x) / ((exp(3 * x) + 1)*(exp(3 * x) + 1)));
}