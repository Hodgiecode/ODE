#pragma warning(disable:4996)
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "task.h"

double correct_answer(double x){
	return x*x*x;
	//return exp(2 * x) / (exp(3 * x) + 1);
}

int main() {
	double a = 0, b = 0, c = 0, d = 0, e = 0, h = 0;
	int value = 0, n = 0;
	FILE *in = NULL, *out = NULL;

	////////  �������       ////////
	/// y'=f(x,y) [a,b] y(a)=d h=c/////
	in = fopen("datin.txt", "r");
	if (in) {
		fscanf(in, "%lf %lf %lf %lf %lf %d ", &a, &b, &c, &d, &e, &n);
	}

	fclose(in);

	//////////////

	h = c; //��� ��������������

	double *f = (double*)malloc(50000);
	double *temp = (double*)malloc(1);
	
	n = n + 1;
	value = odu(f, temp,d, a, b, h, e, n);
	out = fopen("datout.txt", "w");

	if (value == -1){
		fprintf(out, "%d\n", value);
	} else {
		fprintf(out, "%d\n", n-1);
		for (int j = 0; j < n; j++) {
			fprintf(out, "%lf %1.9f\n", a + j*c, f[j]);
		}
	}

	fclose(out);
	free(f);
	free(temp);
	
	return 0;
}
