#pragma warning(disable:4996)
#include "task.h"
#include "funkr.h"

void Runge_Kutta(double *y, double y0, double x0, double h) {
	double k1, k2, k3, k4, x;
	
	for (int i = 0; i<4; i++) {
		x = x0 + h*i;
		k1 = h*func(x, y[i]);
		k2 = h*func(x + h / 2, y[i] + k1/ 2);
		k3 = h*func(x + h / 2, y[i] + k2/ 2);
		k4 = h*func(x + h, y[i] + k3);
		y[i + 1] = y[i] + (k1 + 2 * (k2 + k3) + k4) / 6;
	}
}

void Adams_Moulton(double *y,double y0, double x0, double h, int n){
	double k1, k2, k3, k4;
	double delta;
	double temp1, temp2, temp3;

	y[0] = y0;

	Runge_Kutta(y,y0, x0, h); 

	for (int i = 3; i < n; i++) {
		k1 = func(x0 + i*h, y[i]);
		k2 = func(x0 + (i - 1)*h, y[i - 1]);
		k3 = func(x0 + (i - 2)*h, y[i - 2]);
		k4 = func(x0 + (i - 3)*h, y[i - 3]);
		delta = h*(55 * k1 - 59 * k2 + 37 * k3 - 9 * k4) / 24;
		temp1 = y[i] + delta;

		k1 = func(x0 + (i + 1)*h, temp1);
		k2 = func(x0 + i*h, y[i]);
		k3 = func(x0 + (i - 1)*h, y[i - 1]);
		k4 = func(x0 + (i - 2)*h, y[i - 2]);
		delta = h*(9 * k1 + 19 * k2 - 5 * k3 + k4) / 24;
		temp2 = y[i] + delta;

		k1 = func(x0 + (i + 1)*h, temp2);
		k2 = func(x0 + i*h, y[i]);
		k3 = func(x0 + (i - 1)*h, y[i - 1]);
		k4 = func(x0 + (i - 2)*h, y[i - 2]);
		delta= h*(9 * k1 + 19 * k2 - 5 * k3 + k4) / 24;
		y[i + 1] = y[i] + delta;
	}

}


int odu(double *y, double *temp, double y0, double x0, double b, double h, double e, int n) {
	int i = 0;
	int k = 0;
	
	double *test_1 = (double*)malloc(1000);
	double *test_2 = (double*)malloc(1000);

	int max_iter = 0;

	double h1 = h;
	double h2 = h/2;

	int n1 = n;
	int n2 = 2 * n1;
	int index1 = 0;
	int index2 = 0;
	int flag = 1;

	while (max_iter < 10) {
		Adams_Moulton(y, y0, x0, h1, n1);
		for (int i = 0; i < n1; i++) {
			if (i % (n1 / n) == 0) {
				test_1[index1] = y[i];
				index1 = index1 + 1;
			}
		}

		memset(y, 0, sizeof(y));
		
		Adams_Moulton(y, y0, x0, h2, n2);
		for (int i = 0; i < n2; i++) {
			if (i % (n2 / n) == 0) {
				test_2[index2] = y[i];
				index2 = index2 + 1;
			}
		}

		for (int i = 0; i < n; i++) {
			if (fabs(test_1[i] - test_2[i]) > e) {
				flag = 0;
				break;
			}
		}

		if (flag == 1) {
			printf("Convergent!");
			memset(y, 0, sizeof(y));
			for (int i = 0; i < n; i++) {
				y[i] = test_1[i];
			}
			
			return n;
		}

		memset(y, 0, sizeof(y));
		memset(test_1, 0, sizeof(test_1));
		memset(test_2, 0, sizeof(test_2));

		n1 = n2;
		n2 = 2 * n2;
		h1 = h2;
		h2 = h2 / 2;
		index1 = 0;
		index2 = 0;
		flag = 1;
		max_iter++;
	}

	return 0;
}