#pragma once
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int odu(double *y, double *temp1,double y0, double x0, double b, double x, double e, int number_of_steps);
